package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Profile extends JPanel {

	private Image image;
	private boolean flipped;
	
	public Profile(String str) {
		
		try {
			image = ImageIO.read(new File("/Users/MahlerRevsine/eclipse-workspace/HackNC_2018/Imgs/" + str + ".jpg"));
		} catch(IOException e) {
			try {
				image = ImageIO.read(new File("/Users/MahlerRevsine/eclipse-workspace/HackNC_2018/Imgs/" + str + ".png"));
			} catch (IOException e2) {
				
			}
		}
		
		flipped = false;
		
		setLayout(new BorderLayout());
		
	}
	
	public Image getImage() {
		return image;
	}
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame("WHO");
		frame.setTitle("Hex");
		frame.setDefaultCloseOperation(3);
		
		frame.setContentPane(new Profile("Circle.jpeg"));
		
		frame.setPreferredSize(new Dimension(500,500));
		
		frame.pack();
		frame.setVisible(true);
	}
	
	
	@Override
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		if (flipped)
			setBackground(Color.DARK_GRAY);
		else {
			setBackground(Color.WHITE);
			g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		}
		
	}
	
	public void flip() {
		
		flipped = !flipped;
		repaint();
		
	}
	
	
	
}
