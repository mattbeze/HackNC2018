package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Question extends JDialog implements ActionListener {

	private JPanel main_panel;
	private JPanel top;
	private JPanel first;
	private JPanel second;
	private JPanel third;
	private JComboBox<String> firstMenu;
	private JComboBox<String> affiliation;
	private JComboBox<String> age;
	private JComboBox<String> hair_color;
	private JComboBox<String> name;
	private JComboBox<String> sex;
	private JComboBox<String> skin_color;
	private JButton button;
	
	
	public Question() {
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		main_panel = new JPanel();
		main_panel.setLayout(new GridLayout(5,1));
		
		String[] firstOptions = new String[] {"AFFILIATION", "AGE", "HAIR COLOR", "NAME", "SEX", "SKIN COLOR"};
		firstMenu = new JComboBox<String>(firstOptions);
		firstMenu.setVisible(true);
		firstMenu.setSelectedItem(0);
		firstMenu.addActionListener(this);
		
		top = new JPanel();
		top.setLayout(new BorderLayout());
		
		
		first = new JPanel();
		first.setLayout(new GridLayout(1,2));
		first.add(new JLabel("Pick a Characteristic"));
		
		
		second = new JPanel();
		second.setLayout(new GridLayout(1,2));
		second.add(new JLabel("Pick a Value"));
		
		
		
		third = new JPanel();
		third.setLayout(new BorderLayout());
		
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource().getClass().equals(JComboBox.class)) {
			
		}
	}
	
}
