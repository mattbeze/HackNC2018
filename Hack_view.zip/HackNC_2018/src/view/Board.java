package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;

public class Board extends JPanel {
	
	private String[] names;

	public Board() {
		
		String[] tempstrs = new String[] {
				"Alex",
				"Ben",
				"Carol",
				"Casey",
				"Dean",
				"Diane",
				"Eve",
				"Gary",
				"James",
				"Joanne",
				"Jocelyn",
				"Joel",
				"KMP",
				"Kris",
				"Luke",
				"Mia",
				"Michael",
				"Montek",
				"Paris",
				"Ramses",
				"Remi",
				"Roy",
				"Sam",
				"Theo"
		};
		
		names = randomizeStrings(tempstrs);
		
		setLayout(new GridLayout(2,1));
		setMinimumSize(new Dimension(300,800));
		
		JPanel top = new JPanel();
		top.setLayout(new BorderLayout());
		top.add(new ComputerSide(), BorderLayout.CENTER);
		top.add(new JPanel(), BorderLayout.NORTH);
		top.add(new JPanel(), BorderLayout.SOUTH);
		top.add(new JPanel(), BorderLayout.EAST);
		top.add(new JPanel(), BorderLayout.WEST);
		
		add(top);
		
		JPanel bottom = new JPanel();
		bottom.setLayout(new BorderLayout());
		bottom.add(new PlayerSide(names));
		bottom.add(new JPanel(), BorderLayout.NORTH);
		bottom.add(new JPanel(), BorderLayout.SOUTH);
		bottom.add(new JPanel(), BorderLayout.EAST);
		bottom.add(new JPanel(), BorderLayout.WEST);
		
		add(bottom);
		
	}
	
	public String[] randomizeStrings(String[] strs) {
		String[] temp = new String[strs.length];
		int[] ns = randomizeInts(0,24);
		
		for (int i = 0; i < temp.length; i++) {
			
			temp[i] = strs[ns[i]];
			
		}
		
		return temp;
	}
	
	
	public int[] randomizeInts(int low, int high) {
		int[] nums = new int[high-low];
		
		for (int i = 0; i < 24; i++) {
			
			boolean working = true;
			while (working) {
				nums[i] = (int) Math.floor(low + Math.random()*(high-low));
				boolean done = true;
				loop:
				for (int j = 0; j < i; j++) {
					if (nums[j] == nums[i]) {
						done = false;
						break loop;
					}
				}
				if (done)
					working = false;
			}
			
		}
		
		return nums;
	}
	
}
