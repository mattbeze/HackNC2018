package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PlayerSide extends JPanel {
	
	private String[] names;

	public PlayerSide(String[] names) {
		
		this.names = names;
		
		setLayout(new GridLayout(4,6));
		setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
		
		for (int i = 0; i < names.length; i++) 
			add(new Tile(names[i]));
		
		setMinimumSize(new Dimension(250,750));
		
	}
	
	
//	public static void main(String[] args) {
//		
//		JFrame frame = new JFrame("");
//		frame.setDefaultCloseOperation(3);
//		
//		String[] strs = new String[24];
//		for (int i = 0; i < 24; i++) {
//			strs[i] = "Circle.jpeg";
//		}
//		
//		frame.setContentPane(new PlayerSide(strs));
//		
//		frame.pack();
//		frame.setVisible(true);
//		
//	}
}
