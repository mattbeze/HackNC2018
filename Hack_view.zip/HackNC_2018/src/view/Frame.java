package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Frame extends JFrame implements ActionListener {

	private String[] names;
	private JPanel content;
	private Board board;
	private JPanel menuBar;
	private JButton reset;
	private JButton ask;
	
	public Frame() {
		
		names = new String[24];
		for (int i = 0; i < 24; i++) {
			names[i] = "Circle.jpeg";
 		}
		
		content = new Content();
		
		menuBar = new JPanel();
		menuBar.setLayout(new GridLayout(1,2));
		reset = new JButton("Reset");
		reset.setActionCommand("reset");
		reset.addActionListener(this);
		ask = new JButton("Ask");
		ask.setActionCommand("ask");
		ask.addActionListener(this);
		menuBar.add(reset);
		menuBar.add(ask);
		content.add(menuBar, BorderLayout.NORTH);
		
		setTitle("Guess Whom!");
		setDefaultCloseOperation(3);
		
		setContentPane(content);
		
		setMinimumSize(new Dimension(350,680));
		
		pack();
		setVisible(true);
		
	}
	
	
	public static void main(String[] args) {
		
		Frame f = new Frame();
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getActionCommand().equals("reset")) {
			
			
			
			Thread t = new Thread(new Runnable() { public void run() { 
				 
				content = new Content();
				setContentPane(content);
				
			}});
			
			t.start();
			
			
		} else {
			
			
			
			
			
		}
		
	}
	
}
