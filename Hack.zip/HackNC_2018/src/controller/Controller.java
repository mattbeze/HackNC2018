package controller;

import model.GuessEvent;
import view.ViewEvent;

public class Controller implements view.ViewListener, model.ModelListener {

	private view.Frame frame;
	private model.OpponentController model;
	private boolean turn;
	
	public Controller() {
		
		turn = true;
		this.frame = new view.Frame();
		this.model = new model.OpponentController();
		frame.addListener(this);
		model.addModelListener(this);
	}
	
	public static void main(String[] args) {
		Controller c = new Controller();
	}

	@Override
	public void handleViewEvent(ViewEvent e) {
		// TODO Auto-generated method stub
		if (turn) 
			model.receiveViewEvent(e);
	}

	@Override
	public void HandleModelEvent(boolean b) {
		// TODO Auto-generated method stub
		frame.receiveModelEvent(b);
		turn = !turn;
	}

	@Override
	public void HandleGuessEvent(GuessEvent e) {
		// TODO Auto-generated method stub
		turn = !turn;
		frame.receiveGuessEvent(e);
	}
	
}
