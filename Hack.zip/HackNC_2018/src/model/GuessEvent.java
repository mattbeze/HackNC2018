package model;

import java.util.List;

public class GuessEvent {
	
	private List<CharacterImpl> chars;


	public GuessEvent(List<CharacterImpl> cs) {
		
		chars = cs;
	}
	
	public List<CharacterImpl> getChars() {
		return chars;
	}

}