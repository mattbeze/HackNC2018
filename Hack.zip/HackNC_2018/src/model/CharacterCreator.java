package model;

import java.util.ArrayList;
import java.util.List;

public class CharacterCreator {

	public List<CharacterImpl> createPeople() {
		List<CharacterImpl> characters = new ArrayList<CharacterImpl>();
		
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Carol", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Rameses", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.OVER, Character_Interface.skinColor.BLACK, Character_Interface.Affiliation.OTHER, "Joanne", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Roy", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.UNDER, Character_Interface.skinColor.BLACK, Character_Interface.Affiliation.ATHLETICS, "Joel", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.UNDER, Character_Interface.skinColor.BLACK, Character_Interface.Affiliation.ATHLETICS, "Theo", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Luke", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Diane", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.UNDER, Character_Interface.skinColor.BLACK, Character_Interface.Affiliation.ATHLETICS, "Paris", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Mia", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.OVER, Character_Interface.skinColor.BLACK, Character_Interface.Affiliation.ATHLETICS, "Michael", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "James", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLONDE, Character_Interface.age.UNDER, Character_Interface.skinColor.OTHER, Character_Interface.Affiliation.ATHLETICS, "Remi", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLONDE, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Jocelyn", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Kris", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLONDE, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Casey", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.OTHER, Character_Interface.Affiliation.OTHER, "Sam", true));	
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLACK, Character_Interface.age.OVER, Character_Interface.skinColor.OTHER, Character_Interface.Affiliation.OTHER, "Montek", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Ben", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.OTHER, Character_Interface.Affiliation.OTHER, "Ketan", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BROWN, Character_Interface.age.UNDER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Alex", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.ATHLETICS, "Dean", true));
		characters.add(new CharacterImpl(Character_Interface.hairColor.BLONDE, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Eve", false));
		characters.add(new CharacterImpl(Character_Interface.hairColor.OTHER, Character_Interface.age.OVER, Character_Interface.skinColor.WHITE, Character_Interface.Affiliation.OTHER, "Gary", true));
	
		return characters;
	
	}
	
}
