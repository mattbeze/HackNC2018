package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

public class OpponentController {
	private CharacterImpl target;
	private CharacterImpl oppTarget;
	private List<CharacterImpl> possible;
	private List<ModelListener> listeners;

	public OpponentController() {
		
		CharacterCreator c = new CharacterCreator();
		possible = c.createPeople();
		listeners = new ArrayList<ModelListener>();
		target = generateTarget();
		oppTarget = generateTarget();
		JOptionPane.showConfirmDialog(null, "The Computer Will Try to Guess " + oppTarget.getName());
	}
	
	public void guess() {
		int typeGuess = new Random().nextInt(6); //Sex,Aff,Hair,Skin,Age,Name
		List<CharacterImpl> toBeFlipped = new ArrayList<CharacterImpl>();
		
		switch (typeGuess) {
		
		case 0: 
			boolean b = oppTarget.getAffiliation().equals(Character_Interface.Affiliation.values()[new Random().nextInt(2)]);
			
//			for (CharacterImpl c: possible) {
//				if ()
//			}
//		
		}
		
	}
	
	public CharacterImpl generateTarget() {
		return possible.get((int) (Math.floor(Math.random()*possible.size())));
	}
	
	public void addModelListener(ModelListener l) {
		listeners.add(l);
	}
	
	public void notifyListeners(boolean b) {
		for (ModelListener l: listeners) {
			l.HandleModelEvent(b);
		}
	}
	
	public void receiveViewEvent(view.ViewEvent e) {
		
		boolean answer = false;
		
		if (e.getS1().equals("AFFILIATION")) 
			
			answer = checkAffiliations(e.getS2());
			
		else if (e.getS1().equals("AGE"))
			
			answer = checkAges(e.getS2());
		
		else if (e.getS1().equals("HAIR_COLOR"))
				
			answer = checkHairColors(e.getS2());
		
		else if (e.getS1().equals("NAME"))
			
			answer = checkNames(e.getS2());
		
		else if (e.getS1().equals("SEX"))
			
			answer = checkSexes(e.getS2());
		
		else if (e.getS1().equals("SKIN_COLOR"))
			
			answer = checkSkinColors(e.getS2());
		
		notifyListeners(answer);
		
	}
	
	public boolean checkAffiliations(String s) {
		
		if (s.equals("ATHLETICS")) {
			return target.getAffiliation().equals(Character_Interface.Affiliation.ATHLETICS);
		} else {
			return target.getAffiliation().equals(Character_Interface.Affiliation.OTHER);
		}
		
	}
	
	public boolean checkAges(String s) {
		
		if (s.equals("UNDER 25"))
			return target.getAge().equals(Character_Interface.age.UNDER);
		else
			return target.getAge().equals(Character_Interface.age.OVER);
		
	}

	public boolean checkHairColors(String s) {
		
		if (s.equals("BLACK"))
			return target.getHair().equals(Character_Interface.hairColor.BLACK);
		else if (s.equals("BROWN"))
			return target.getHair().equals(Character_Interface.hairColor.BROWN);
		else if (s.equals("BLONDE"))
			return target.getHair().equals(Character_Interface.hairColor.BLONDE);
		else
			return target.getHair().equals(Character_Interface.hairColor.BLONDE);
		
	}
	
	public boolean checkNames(String s) {
		
		if (s.equalsIgnoreCase(target.getName())) {
			JOptionPane.showConfirmDialog(null, "YOU WIN!", "Game Over", 0, 0);
		}
		return s.equalsIgnoreCase(target.getName());
	}
	
	public boolean checkSexes(String s) {
		
		if (s.equals("FEMALE"))
			return !target.isMale();
		else
			return target.isMale();
	}
	
	public boolean checkSkinColors(String s) {
		
		if (s.equals("WHITE"))
			return target.getSkin().equals(Character_Interface.skinColor.WHITE);
		else if (s.equals("BLACK"))
			return target.getSkin().equals(Character_Interface.skinColor.BLACK);
		else
			return target.getSkin().equals(Character_Interface.skinColor.OTHER);
	}
	
}
