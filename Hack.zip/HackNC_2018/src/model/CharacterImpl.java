package model;

public class CharacterImpl {

	private String name;
	 private boolean isMale;
	 private Character_Interface.hairColor hairColor;
	 private Character_Interface.age age;
	 private Character_Interface.skinColor skinColor;
	private Character_Interface.Affiliation Affiliation;
	
	
	public String getName() {
		return name;
	}

	
	public boolean isMale() {
		if (isMale)
			return true;
		else
			return false;
	}
	public CharacterImpl(Character_Interface.hairColor hair, Character_Interface.age age, Character_Interface.skinColor skin, Character_Interface.Affiliation aff, String name, boolean isMale)
	{
		this.hairColor = hair;
		this.age = age;
		this.skinColor = skin;
		this.Affiliation = aff;
		this.name = name;
		this.isMale = isMale;
	}

	public String toString() {
		if (isMale)
		return name + " is a male that has " + hairColor + " hair, " + skinColor + " skin, is affiliated with "+ Affiliation +  ", and is " + age + " 25.";
		else
		return name + " is a female that has " + hairColor + " hair, " + skinColor + " skin, is affiliated with "+ Affiliation +  ", and is " + age + " 25.";
	}
	
	public Character_Interface.hairColor getHair() {
		return hairColor;
	}
	public Character_Interface.Affiliation getAffiliation() {
		return Affiliation;
	}
	public Character_Interface.age getAge() {
		return age;
	}
	public Character_Interface.skinColor getSkin() {
		return skinColor;
	}
	
}
