package model;

public interface ModelListener {

	public void HandleModelEvent(boolean b);
	public void HandleGuessEvent(GuessEvent e);
	
}
