package view;

import java.awt.BorderLayout;

import javax.swing.JPanel;

public class Content extends JPanel {

	
	public Content() {
		
		setLayout(new BorderLayout());
		add(new Board(), BorderLayout.CENTER);
		
	}
	
	
}
