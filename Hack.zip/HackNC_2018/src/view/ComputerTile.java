package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ComputerTile extends JPanel {
	
	public ComputerTile() {
		
		setLayout(new BorderLayout());
		setBackground(Color.WHITE);
		
		setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
		
		JLabel label = new JLabel();
		label.setFont(new Font("sans-serif", Font.BOLD, 32));
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setText("?");
		
		add(label);
	}
	
	public void flip() {
		
		if (getBackground().equals(Color.LIGHT_GRAY))
			setBackground(Color.BLACK);
		
	}
}
