package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tile extends JPanel implements MouseListener {

	private Profile profile;
	private JLabel label;
	
	public Tile(String str) {
		
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY.darker(),2));
		
		profile = new Profile(str);
		add(profile, BorderLayout.CENTER);
		label = new JLabel(str);
		add(label, BorderLayout.SOUTH);
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setBackground(Color.BLACK);
		
		addMouseListener(this);
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		if (e.getClickCount() == 1) {
			
			profile.flip();
			
			if (label.getBackground().equals(Color.BLACK)) {
				label.setBackground(Color.LIGHT_GRAY);
				label.setForeground(Color.LIGHT_GRAY);
			} else {
				label.setBackground(Color.BLACK);
				label.setForeground(Color.BLACK);
			}
			
			
			
		} else {
			
			profile.flip();
			
			if (label.getBackground().equals(Color.BLACK)) {
				label.setBackground(Color.LIGHT_GRAY);
				label.setForeground(Color.LIGHT_GRAY);
			} else {
				label.setBackground(Color.BLACK);
				label.setForeground(Color.BLACK);
			}
			
			JDialog dialog = new JDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			JLabel label = new JLabel(new ImageIcon(profile.getImage()));
			dialog.setLayout(new BorderLayout());
			dialog.add(label, BorderLayout.CENTER);
			dialog.pack();
			dialog.setVisible(true);
			
		}

	}
	
//	public static void main(String[] args) {
//		
//		JFrame frame = new JFrame("ijd");
//		frame.setDefaultCloseOperation(3);
//		
//		JPanel hold = new JPanel();
//		hold.setLayout(new BorderLayout());
//		hold.add(new Tile("Circle.jpeg"), BorderLayout.CENTER);
//		
//		frame.setContentPane(hold);
//		frame.setMinimumSize(new Dimension(300,300));
//		
//		frame.pack();
//		frame.setVisible(true);
//		
//	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
