package view;

public interface ViewListener {

	public void handleViewEvent(ViewEvent e);
	
}
