package view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ComputerSide extends JPanel {

	public ComputerTile[] tiles;
	
	public ComputerSide() {
		
		setLayout(new GridLayout(4,6));
		setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		tiles = new ComputerTile[24];
		
		for (int i = 0; i < 24; i++) {
			
			ComputerTile t = new ComputerTile();
			tiles[i] = t;
			add(t);
			
		}
		
	}
	
	public void flip(int index) {
		
		tiles[index].setBackground(Color.DARK_GRAY);
		
	}
	
	public void flipRandom() {
		
		boolean unfinished = true;
		while (unfinished) {
			
			ComputerTile t = tiles[(int)Math.floor(Math.random()*24)];
			if (t.getBackground().equals(Color.WHITE)) {
				t.flip();
				unfinished = false;
			}
			
			
		}
		
	}
 	
	
//	public static void main(String[] args) {
//		
//		JFrame frame = new JFrame("");
//		frame.setDefaultCloseOperation(3);
//		
//		frame.setContentPane(new ComputerSide());
//		
//		frame.pack();
//		frame.setVisible(true);
//		
//	}
	
}
