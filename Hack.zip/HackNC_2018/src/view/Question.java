package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Question extends JDialog implements ActionListener {

	private JPanel main_panel;
	private JPanel top;
	private JPanel first;
	private JPanel second;
	private JPanel third;
	private JPanel bottom;
	private JLabel error;
	private JLabel answer;
	private JComboBox<String> firstMenu;
	private JComboBox<String> secondMenu;
	private String[] affiliations;
	private String[] ages;
	private String[] hair_colors;
	private String[] names;
	private String[] sexes;
	private String[] skin_colors;
	private JButton button;
	private String firstChoice;
	private String secondChoice;
	private Frame frame;
	
	public Question(Frame frame) {
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		this.frame = frame;
		firstChoice = "";
		secondChoice = "";
		
		main_panel = new JPanel();
		main_panel.setLayout(new GridLayout(5,1));
		
		String[] firstOptions = new String[] {"", "AFFILIATION", "AGE", "HAIR COLOR", "NAME", "SEX", "SKIN COLOR"};
		affiliations = new String[] {"", "ATHLETICS", "OTHER"};
		ages = new String[] {"", "UNDER 25", "OVER 25"};
		hair_colors = new String[] {"", "BLACK", "BROWN", "BLONDE", "OTHER"};
		names = new String[] {"", "ALEX", "BEN", "CAROL", "CASEY", "DEAN", "DIANE",
				"EVE", "GARY", "JAMES", "JOANNE", "JOCELYN", "JOEL", "KMP", "KRIS", "LUKE", "MIA",
				"MICHAEL", "MONTEK", "PARIS", "RAMSES", "REMI", "ROY", "SAM", "THEO"};
		sexes = new String[] {"", "FEMALE", "MALE"};
		skin_colors = new String[] {"", "WHITE", "BLACK", "OTHER"};
		
		firstMenu = new JComboBox<String>(firstOptions);
		firstMenu.setVisible(true);
		firstMenu.setSelectedItem(0);
		firstMenu.addActionListener(this);
		
		secondMenu = new JComboBox<String>(affiliations);
		secondMenu.setVisible(true);
		secondMenu.setSelectedItem(0);
		secondMenu.addActionListener(this);
		
		button = new JButton("Submit");
		button.setActionCommand("submit");
		button.addActionListener(this);
		
		error = new JLabel("Something went wrong, try again");
		error.setForeground(Color.RED);
		error.setHorizontalAlignment(JLabel.CENTER);
		error.setVisible(false);
		
		top = new JPanel();
		top.setLayout(new BorderLayout());pack();
		top.add(error);
		
		first = new JPanel();
		first.setLayout(new GridLayout(1,2));
		first.add(new JLabel("Pick a Characteristic:"));
		first.add(firstMenu);
		
		second = new JPanel();
		second.setLayout(new GridLayout(1,2));
		second.add(new JLabel("Pick a Value:"));
		second.add(secondMenu);
		
		third = new JPanel();
		third.setLayout(new BorderLayout());
		third.add(button);
		
		bottom = new JPanel();
		bottom.setLayout(new BorderLayout());
		
		answer = new JLabel();
		answer.setFont(new Font("sans-serif", Font.BOLD, 24));
		answer.setHorizontalAlignment(JLabel.CENTER);
		
		bottom.add(answer);
		
		main_panel.add(top);
		main_panel.add(first);
		main_panel.add(second);
		main_panel.add(third);
		main_panel.add(bottom);
		
		setContentPane(main_panel);
		setMinimumSize(new Dimension(150,300));
		setMaximumSize(new Dimension(150,300));
		
		pack();
		setVisible(true);
		
	}
	
	public void displayAnswer(boolean b) {
		if (b) {
			answer.setText("YES!");
		} else {
			answer.setText("NO!");
		}
		bottom.repaint();
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource().equals(button)) {
			String cmd = e.getActionCommand();
			
			if (cmd.equals("submit")) { 
				if (firstChoice.equals("") || secondChoice.equals("")) {
					
					error.setVisible(true);
					
				} else {
					
					error.setVisible(false);
					frame.notifyListeners(new ViewEvent(firstChoice, secondChoice));
					
					
				}
				
			}
		} else {
			
			JComboBox<String> cb = (JComboBox)e.getSource();
			String cmd = (String) cb.getSelectedItem();
			
			if (cmd.equals("AFFILIATIONS")) {	
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( affiliations );
				secondMenu.setModel(model);
			} else if (cmd.equals("AGE")) {
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( ages );
				secondMenu.setModel(model);
			} else if (cmd.equals("HAIR COLOR")) {
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( hair_colors );
				secondMenu.setModel(model);
			} else if (cmd.equals("NAME")) {
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( names );
				secondMenu.setModel(model);
			} else if (cmd.equals("SEX")) {
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( sexes );
				secondMenu.setModel(model);
			} else if (cmd.equals("SKIN COLOR")) {
				error.setVisible(false);
				firstChoice = cmd;
				DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>( skin_colors );
				secondMenu.setModel(model);
			} else if (cmd.equals("")) {
				error.setVisible(false);
			} else {
				error.setVisible(false);
				secondChoice = cmd;
			}
		}

	}
	
}
